HiveMind 🌌

Sync Your Soul with the Cosmic Pulse

HiveMind is a futuristic web app that channels your emotions into the universe’s rhythm. With a sci-fi interface featuring a cosmic void, ambient music, and quantum-inspired insights, it analyzes your mood, connects you to collective vibes, and offers personalized cosmic guidance. Hosted on AWS Elastic Beanstalk’s free tier and available on GitHub, HiveMind is your gateway to the multiverse, now with user authentication and mood tracking.

Features





Sci-Fi Interface: Cosmic void backdrop with twinkling stars and neon cyan/magenta accents.



Ambient Soundtrack: Immersive sci-fi music with play/pause control.



Sentiment Analysis: Detects your mood (POSITIVE/NEGATIVE) with confidence scores using VADER.



Universal Pulse: Reflects collective vibes via dummy social trends (real-time X trends planned).



Cosmic Insights: Tailored suggestions to harmonize your energy (e.g., “Your vibe is stellar!”).



User Accounts: Sign up, log in, and track your mood history.



Responsive Design: Seamless on mobile and desktop.



Zero-Cost: Deployed on AWS Elastic Beanstalk’s free tier.

Tech Stack





Backend: Python 3.11, Flask 3.0.3, Flask-Login, SQLite



Sentiment Analysis: VADER Sentiment 3.3.2



Frontend: HTML, CSS, JavaScript



Audio: Royalty-free MP3 (Pixabay)



Fonts: Exo 2, Source Code Pro (Google Fonts)



Hosting: AWS Elastic Beanstalk (free tier)

Prerequisites





AWS account (free tier) or local Python environment.



Internet connection for external audio and fonts.



Modern browser (Chrome, Firefox recommended) with audio autoplay enabled.

Setup Instructions

On AWS Elastic Beanstalk





Set Up AWS:





Sign up for an AWS account at aws.amazon.com.



Install AWS CLI and EB CLI:

brew install awscli
pip3 install awsebcli



Clone the Repository:





Clone this repo:

git clone https://github.com/<your-username>/HiveMind.git
cd HiveMind



Configure AWS CLI:





Run:

aws configure



Enter your AWS Access Key ID, Secret Access Key, region (e.g., us-east-1), and output format (json).



Initialize Elastic Beanstalk:





Run:

eb init -p python-3.11 HiveMind --region us-east-1



Create Environment:





Run:

eb create hivemind-env --single



Deploy:





Run:

eb deploy



Access the app at the provided URL (e.g., http://hivemind-env.<random>.us-east-1.elasticbeanstalk.com).

Locally





Clone the Repository:





Clone this repo:

git clone https://github.com/<your-username>/HiveMind.git
cd HiveMind



Install Dependencies:





Ensure Python 3.11 is installed.



Run:

pip3 install -r requirements.txt



Run the App:





Execute:

python3 app.py



Open http://localhost:8000 in a browser.

Usage





Launch the App:





Navigate to the AWS URL or http://localhost:8000.



Sign up or log in to access the cosmic dashboard.



Input Your Mood:





Enter your emotional state (e.g., “Feeling stellar today” or “Lost in the void”).



Click Sync with the Void.



Explore Results:





Quantum State: Your mood (POSITIVE/NEGATIVE) with a sync percentage.



Universal Pulse: Collective vibe percentage.



Cosmic Insight: Guidance to align your energy.



Manage Music:





Toggle the Play/Pause Music button to control the sci-fi soundtrack.

Future Enhancements





Real-time X API integration for dynamic Universal Pulse.



Community vibe dashboard showing global user moods as a cosmic heatmap.



Customizable UI with theme and music track options.



AI-driven cosmic insights with deeper personalization.



Scalable hosting with AWS RDS for database management.

Acknowledgments





Crafted with passion for the multiverse, inspired by quantum entanglement and cosmic consciousness.



Gratitude to Pixabay for royalty-free audio and Google Fonts for sci-fi typography.



Thanks to AWS for free-tier hosting via Elastic Beanstalk.

Sync with the void and discover your cosmic state! 🌌