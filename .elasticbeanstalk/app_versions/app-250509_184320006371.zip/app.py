from flask import Flask, request, jsonify, render_template, redirect, url_for, flash
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
import sqlite3
from werkzeug.security import generate_password_hash, check_password_hash
import os

app = Flask(__name__)
app.secret_key = 'cosmic_void_123'  # Change for production

# SQLite path for AWS
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, 'data', 'hivemind.db')

# Initialize Flask-Login
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

# Initialize sentiment analyzer
sentiment_analyzer = SentimentIntensityAnalyzer()

# SQLite database setup
def init_db():
    with sqlite3.connect(DB_PATH) as conn:
        c = conn.cursor()
        c.execute('''CREATE TABLE IF NOT EXISTS users 
                     (id INTEGER PRIMARY KEY AUTOINCREMENT, 
                      username TEXT UNIQUE, 
                      password TEXT)''')
        c.execute('''CREATE TABLE IF NOT EXISTS moods 
                     (id INTEGER PRIMARY KEY AUTOINCREMENT, 
                      user_id INTEGER, 
                      mood_text TEXT, 
                      mood_label TEXT, 
                      confidence REAL, 
                      timestamp DATETIME DEFAULT CURRENT_TIMESTAMP)''')
        conn.commit()

# User class for Flask-Login
class User(UserMixin):
    def __init__(self, id, username):
        self.id = id
        self.username = username

@login_manager.user_loader
def load_user(user_id):
    with sqlite3.connect(DB_PATH) as conn:
        c = conn.cursor()
        c.execute('SELECT id, username FROM users WHERE id = ?', (user_id,))
        user = c.fetchone()
        if user:
            return User(user[0], user[1])
        return None

# Dummy X trends (to be replaced with real API)
def get_x_trends():
    tweets = [
        "The universe feels alive today!",
        "Struggling to find my center.",
        "New tech is sparking ideas!"
    ]
    sentiments = [sentiment_analyzer.polarity_scores(tweet)['compound'] for tweet in tweets]
    positive_count = sum(1 for s in sentiments if s > 0)
    total = len(sentiments)
    positive_percentage = (positive_count / total) * 100 if total > 0 else 0
    return positive_percentage

@app.route('/')
def home():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        with sqlite3.connect(DB_PATH) as conn:
            c = conn.cursor()
            c.execute('SELECT id, username, password FROM users WHERE username = ?', (username,))
            user = c.fetchone()
            if user and check_password_hash(user[2], password):
                login_user(User(user[0], user[1]))
                return redirect(url_for('dashboard'))
            flash('Invalid username or password')
    return render_template('login.html')

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        if not username or not password:
            flash('Username and password are required')
            return render_template('signup.html')
        hashed_password = generate_password_hash(password, method='pbkdf2:sha256')
        try:
            with sqlite3.connect(DB_PATH) as conn:
                c = conn.cursor()
                c.execute('INSERT INTO users (username, password) VALUES (?, ?)', 
                         (username, hashed_password))
                conn.commit()
                c.execute('SELECT id, username FROM users WHERE username = ?', (username,))
                user = c.fetchone()
                login_user(User(user[0], user[1]))
                return redirect(url_for('dashboard'))
        except sqlite3.IntegrityError:
            flash('Username already exists')
    return render_template('signup.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('login'))

@app.route('/dashboard')
@login_required
def dashboard():
    return render_template('dashboard.html', username=current_user.username)

@app.route('/analyze', methods=['POST'])
@login_required
def analyze():
    user_mood = request.form.get('mood')
    if not user_mood:
        return jsonify({'error': 'Enter your cosmic state!'})

    # Analyze mood
    mood_analysis = sentiment_analyzer.polarity_scores(user_mood)
    compound_score = mood_analysis['compound']
    mood_label = 'POSITIVE' if compound_score > 0 else 'NEGATIVE'
    mood_score = abs(compound_score)

    # Save mood to database
    with sqlite3.connect(DB_PATH) as conn:
        c = conn.cursor()
        c.execute('INSERT INTO moods (user_id, mood_text, mood_label, confidence) VALUES (?, ?, ?, ?)',
                 (current_user.id, user_mood, mood_label, mood_score))
        conn.commit()

    # Collective vibe
    positive_percentage = get_x_trends()

    # Cosmic suggestions
    suggestions = {
        'POSITIVE': [
            "Your energy is resonating! Share your spark with the universe.",
            "You're in sync with the cosmos! Start a new venture today.",
            "Your vibe is stellar! Reflect on your cosmic journey."
        ],
        'NEGATIVE': [
            "Feeling disconnected? Meditate to realign your energy.",
            "The void is heavy. Listen to calming frequencies to recharge.",
            "Low vibes? Connect with a friend to share cosmic insights."
        ]
    }
    suggestion = suggestions[mood_label][hash(user_mood) % len(suggestions[mood_label])]

    return jsonify({
        'mood': mood_label,
        'confidence': mood_score,
        'collective_positive': positive_percentage,
        'suggestion': suggestion
    })

if __name__ == '__main__':
    init_db()
    app.run(debug=False, host='0.0.0.0', port=8000)